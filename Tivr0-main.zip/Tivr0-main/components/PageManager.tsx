import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CustomPage, PageComponent, SectionTemplate, NavigationItem, ExtendedSiteSettings } from '../types';
import { Plus, Edit2, Trash2, Eye, EyeOff, GripVertical, Save, X, ArrowUp, ArrowDown, Copy, Settings, Layout, Type, Image, Video, Link, Square, Code, Sliders, MousePointer } from 'lucide-react';

interface PageManagerProps {
  onUpdate?: () => void;
}

export const PageManager: React.FC<PageManagerProps> = ({ onUpdate }) => {
  const { t, lang } = useApp();
  const [pages, setPages] = useState<CustomPage[]>([]);
  const [templates, setTemplates] = useState<SectionTemplate[]>([]);
  const [editingPage, setEditingPage] = useState<CustomPage | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<PageComponent | null>(null);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'pages' | 'templates' | 'navigation'>('pages');

  // Load pages from localStorage on mount
  useEffect(() => {
    const savedPages = localStorage.getItem('customPages');
    if (savedPages) {
      try {
        const parsedPages = JSON.parse(savedPages);
        setPages(parsedPages);
        // Also save to global state for navigation
        localStorage.setItem('navigationPages', JSON.stringify(parsedPages.filter(p => p.showInNavigation)));
      } catch (error) {
        console.error('Error loading pages:', error);
      }
    }
  }, []);

  // Default templates
  useEffect(() => {
    const defaultTemplates: SectionTemplate[] = [
      {
        id: 'hero',
        name: 'hero',
        displayName: { ar: 'القسم الرئيسي', en: 'Hero Section' },
        description: { ar: 'قسم البداية الجذاب', en: 'Attractive introduction section' },
        category: 'hero',
        defaultComponents: [
          {
            id: 'hero-title',
            type: 'text',
            content: { text: { ar: 'مرحباً بك في عالمنا', en: 'Welcome to Our World' } },
            display: 'section',
            styles: {
              colors: { primary: '#1e293b' },
              sizes: { fontSize: 'text-4xl', padding: 'p-6' }
            },
            orderIndex: 0,
            isVisible: true
          },
          {
            id: 'hero-subtitle',
            type: 'text',
            content: { text: { ar: 'نقدم لك أفضل الحلول', en: 'We offer the best solutions' } },
            display: 'section',
            styles: {
              colors: { text: '#64748b' },
              sizes: { fontSize: 'text-lg', padding: 'p-4' }
            },
            orderIndex: 1,
            isVisible: true
          },
          {
            id: 'hero-cta',
            type: 'button',
            content: { 
              text: { ar: 'ابدأ الآن', en: 'Get Started' },
              href: '#contact',
              style: 'primary'
            },
            display: 'section',
            styles: {
              margins: { top: 'mt-4' }
            },
            orderIndex: 1,
            isVisible: true
          }
        ]
      },
      {
        id: 'pricing',
        name: 'pricing',
        displayName: { ar: 'الأسعار', en: 'Pricing' },
        description: { ar: 'عرض خطط الأسعار', en: 'Display pricing plans' },
        category: 'pricing',
        defaultComponents: [
          {
            id: 'pricing-title',
            type: 'text',
            content: { text: { ar: 'خطط الأسعار', en: 'Pricing Plans' } },
            display: 'section',
            styles: {
              colors: { primary: '#1e293b' },
              sizes: { fontSize: 'text-3xl', padding: 'p-6' }
            },
            orderIndex: 0,
            isVisible: true
          }
        ]
      },
      {
        id: 'faq',
        name: 'faq',
        displayName: { ar: 'الأسئلة الشائعة', en: 'FAQ' },
        description: { ar: 'قسم الأسئلة والأجوبة الشائعة', en: 'Frequently asked questions section' },
        category: 'faq',
        defaultComponents: [
          {
            id: 'faq-title',
            type: 'text',
            content: { text: { ar: 'الأسئلة الشائعة', en: 'Frequently Asked Questions' } },
            display: 'section',
            styles: {
              colors: { primary: '#1e293b' },
              sizes: { fontSize: 'text-2xl', padding: 'p-6' }
            },
            orderIndex: 0,
            isVisible: true
          }
        ]
      }
    ];
    setTemplates(defaultTemplates);
  }, []);

  const createNewPage = () => {
    const newPage: CustomPage = {
      id: `page-${Date.now()}`,
      name: '',
      slug: '',
      title: { ar: '', en: '' },
      description: { ar: '', en: '' },
      components: [],
      isVisible: true,
      showInNavigation: true,
      navigationOrder: pages.length,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setEditingPage(newPage);
  };

  const savePage = async () => {
    if (!editingPage) return;
    
    setSaving(true);
    try {
      // Generate slug from name if empty
      if (!editingPage.slug && editingPage.name) {
        editingPage.slug = editingPage.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      }
      
      const existingIndex = pages.findIndex(p => p.id === editingPage.id);
      let updatedPages;
      
      if (existingIndex >= 0) {
        updatedPages = [...pages];
        updatedPages[existingIndex] = { ...editingPage, updatedAt: new Date().toISOString() };
      } else {
        updatedPages = [...pages, editingPage];
      }
      
      setPages(updatedPages);
      
      // Save to localStorage for persistence
      localStorage.setItem('customPages', JSON.stringify(updatedPages));
      // Also save to navigation state
      localStorage.setItem('navigationPages', JSON.stringify(updatedPages.filter(p => p.showInNavigation)));
      
      setEditingPage(null);
      onUpdate?.();
    } catch (error) {
      console.error('Error saving page:', error);
    } finally {
      setSaving(false);
    }
  };

  const deletePage = (pageId: string) => {
    if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذه الصفحة؟' : 'Are you sure you want to delete this page?')) {
      const updatedPages = pages.filter(p => p.id !== pageId);
      setPages(updatedPages);
      localStorage.setItem('customPages', JSON.stringify(updatedPages));
      localStorage.setItem('navigationPages', JSON.stringify(updatedPages.filter(p => p.showInNavigation)));
      onUpdate?.();
    }
  };

  const togglePageVisibility = (pageId: string) => {
    const updatedPages = pages.map(p => 
      p.id === pageId ? { ...p, isVisible: !p.isVisible } : p
    );
    setPages(updatedPages);
    localStorage.setItem('customPages', JSON.stringify(updatedPages));
    localStorage.setItem('navigationPages', JSON.stringify(updatedPages.filter(p => p.showInNavigation)));
    onUpdate?.();
  };

  const addComponentToPage = (templateId: string) => {
    if (!editingPage) return;
    
    const template = templates.find(t => t.id === templateId);
    if (!template) return;
    
    const newComponents = template.defaultComponents.map(comp => ({
      ...comp,
      id: `${comp.id}-${Date.now()}`
    }));
    
    setEditingPage({
      ...editingPage,
      components: [...editingPage.components, ...newComponents]
    });
  };

  const addCustomComponent = (type: PageComponent['type']) => {
    if (!editingPage) return;
    
    const newComponent: PageComponent = {
      id: `component-${Date.now()}`,
      type,
      content: getDefaultContent(type),
      display: 'section',
      styles: getDefaultStyles(type),
      orderIndex: editingPage.components.length,
      isVisible: true
    };
    
    setEditingPage({
      ...editingPage,
      components: [...editingPage.components, newComponent]
    });
  };

  const getDefaultContent = (type: PageComponent['type']) => {
    switch (type) {
      case 'text':
        return { text: { ar: 'نص جديد', en: 'New Text' } };
      case 'image':
        return { src: '', alt: { ar: 'صورة', en: 'Image' } };
      case 'video':
        return { src: '', poster: '', autoplay: false };
      case 'button':
        return { text: { ar: 'زر', en: 'Button' }, href: '#', style: 'primary' };
      case 'html':
        return { html: '' };
      default:
        return {};
    }
  };

  const getDefaultStyles = (type: PageComponent['type']) => {
    return {
      colors: { primary: '#1e293b', text: '#64748b' },
      sizes: { fontSize: 'text-base', padding: 'p-4' },
      margins: { top: 'mt-4', bottom: 'mb-4' }
    };
  };

  const moveComponent = (index: number, direction: 'up' | 'down') => {
    if (!editingPage) return;
    
    const components = [...editingPage.components];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (newIndex >= 0 && newIndex < components.length) {
      [components[index], components[newIndex]] = [components[newIndex], components[index]];
      components.forEach((comp, i) => comp.orderIndex = i);
      
      setEditingPage({
        ...editingPage,
        components
      });
    }
  };

  const deleteComponent = (componentId: string) => {
    if (!editingPage) return;
    
    setEditingPage({
      ...editingPage,
      components: editingPage.components.filter(c => c.id !== componentId)
    });
  };

  const updateComponentInPage = (updatedComponent: PageComponent) => {
    if (!editingPage) return;
    
    setEditingPage({
      ...editingPage,
      components: editingPage.components.map(c => 
        c.id === updatedComponent.id ? updatedComponent : c
      )
    });
  };

  const getComponentIcon = (type: PageComponent['type']) => {
    switch (type) {
      case 'text': return <Type size={16} />;
      case 'image': return <Image size={16} />;
      case 'video': return <Video size={16} />;
      case 'link': return <Link size={16} />;
      case 'button':
        return <Square size={16} />;
      case 'html': return <Code size={16} />;
      case 'slider': return <Sliders size={16} />;
      case 'interactive': return <MousePointer size={16} />;
      default: return <Layout size={16} />;
    }
  };

  if (editingPage) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-slate-900">
            {editingPage.name ? lang === 'ar' ? `تعديل: ${editingPage.name}` : `Edit: ${editingPage.name}` : lang === 'ar' ? 'صفحة جديدة' : 'New Page'}
          </h3>
          <div className="flex gap-2">
            <button
              onClick={savePage}
              disabled={saving || !editingPage.name}
              className="bg-tivro-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-500 disabled:opacity-50 flex items-center gap-2"
            >
              <Save size={16} />
              {saving ? (lang === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (lang === 'ar' ? 'حفظ' : 'Save')}
            </button>
            <button
              onClick={() => setEditingPage(null)}
              className="bg-slate-100 text-slate-700 px-4 py-2 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2"
            >
              <X size={16} />
              {lang === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Page Settings */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                {lang === 'ar' ? 'اسم الصفحة' : 'Page Name'}
              </label>
              <input
                type="text"
                value={editingPage.name}
                onChange={(e) => setEditingPage({ ...editingPage, name: e.target.value })}
                className="w-full border border-slate-200 rounded-lg p-2"
                placeholder={lang === 'ar' ? 'أدخل اسم الصفحة' : 'Enter page name'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                {lang === 'ar' ? 'المسار (URL)' : 'URL Path'}
              </label>
              <input
                type="text"
                value={editingPage.slug}
                onChange={(e) => setEditingPage({ ...editingPage, slug: e.target.value })}
                className="w-full border border-slate-200 rounded-lg p-2"
                placeholder={lang === 'ar' ? 'page-url' : 'page-url'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                {lang === 'ar' ? 'العنوان (عربي)' : 'Title (Arabic)'}
              </label>
              <input
                type="text"
                value={editingPage.title.ar}
                onChange={(e) => setEditingPage({ 
                  ...editingPage, 
                  title: { ...editingPage.title, ar: e.target.value } 
                })}
                className="w-full border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                {lang === 'ar' ? 'العنوان (إنجليزي)' : 'Title (English)'}
              </label>
              <input
                type="text"
                value={editingPage.title.en}
                onChange={(e) => setEditingPage({ 
                  ...editingPage, 
                  title: { ...editingPage.title, en: e.target.value } 
                })}
                className="w-full border border-slate-200 rounded-lg p-2"
              />
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editingPage.isVisible}
                  onChange={(e) => setEditingPage({ ...editingPage, isVisible: e.target.checked })}
                  className="rounded"
                />
                {lang === 'ar' ? 'مرئي' : 'Visible'}
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editingPage.showInNavigation}
                  onChange={(e) => setEditingPage({ ...editingPage, showInNavigation: e.target.checked })}
                  className="rounded"
                />
                {lang === 'ar' ? 'إظهار في القائمة' : 'Show in Navigation'}
              </label>
            </div>
          </div>

          {/* Component Editor */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex justify-between items-center">
              <h4 className="font-bold text-slate-900">
                {lang === 'ar' ? 'المكونات' : 'Components'}
              </h4>
              <div className="flex gap-2">
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      addComponentToPage(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="border border-slate-200 rounded-lg p-2 text-sm"
                >
                  <option value="">{lang === 'ar' ? 'إضافة قالب جاهز' : 'Add Template'}</option>
                  {templates.map(template => (
                    <option key={template.id} value={template.id}>
                      {template.displayName[lang]}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => addCustomComponent('text')}
                  className="bg-blue-50 text-blue-600 px-3 py-1 rounded text-sm font-medium"
                >
                  + {lang === 'ar' ? 'نص' : 'Text'}
                </button>
                <button
                  onClick={() => addCustomComponent('image')}
                  className="bg-green-50 text-green-600 px-3 py-1 rounded text-sm font-medium"
                >
                  + {lang === 'ar' ? 'صورة' : 'Image'}
                </button>
                <button
                  onClick={() => addCustomComponent('button')}
                  className="bg-purple-50 text-purple-600 px-3 py-1 rounded text-sm font-medium"
                >
                  + {lang === 'ar' ? 'زر' : 'Button'}
                </button>
              </div>
            </div>

            {/* Component Editor */}
            {selectedComponent && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h5 className="font-bold text-blue-900">
                    {lang === 'ar' ? 'تحرير المكون' : 'Edit Component'}: {selectedComponent.type}
                  </h5>
                  <button
                    onClick={() => setSelectedComponent(null)}
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <X size={16} />
                  </button>
                </div>
                
                {/* Text Component Editor */}
                {selectedComponent.type === 'text' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'النص (عربي)' : 'Text (Arabic)'}
                      </label>
                      <textarea
                        value={selectedComponent.content.text?.ar || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              text: {
                                ...selectedComponent.content.text,
                                ar: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                        rows={3}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'النص (إنجليزي)' : 'Text (English)'}
                      </label>
                      <textarea
                        value={selectedComponent.content.text?.en || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              text: {
                                ...selectedComponent.content.text,
                                en: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                        rows={3}
                      />
                    </div>
                  </div>
                )}

                {/* Button Component Editor */}
                {selectedComponent.type === 'button' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'نص الزر (عربي)' : 'Button Text (Arabic)'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.text?.ar || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              text: {
                                ...selectedComponent.content.text,
                                ar: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'نص الزر (إنجليزي)' : 'Button Text (English)'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.text?.en || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              text: {
                                ...selectedComponent.content.text,
                                en: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'الرابط' : 'Link'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.href || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              href: e.target.value
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                        placeholder="#"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'النمط' : 'Style'}
                      </label>
                      <select
                        value={selectedComponent.content.style || 'primary'}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              style: e.target.value
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                      >
                        <option value="primary">{lang === 'ar' ? 'أساسي' : 'Primary'}</option>
                        <option value="secondary">{lang === 'ar' ? 'ثانوي' : 'Secondary'}</option>
                        <option value="outline">{lang === 'ar' ? 'إطار' : 'Outline'}</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Image Component Editor */}
                {selectedComponent.type === 'image' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'رابط الصورة' : 'Image URL'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.src || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              src: e.target.value
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'النص البديل (عربي)' : 'Alt Text (Arabic)'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.alt?.ar || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              alt: {
                                ...selectedComponent.content.alt,
                                ar: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {lang === 'ar' ? 'النص البديل (إنجليزي)' : 'Alt Text (English)'}
                      </label>
                      <input
                        type="text"
                        value={selectedComponent.content.alt?.en || ''}
                        onChange={(e) => {
                          const updatedComponent = {
                            ...selectedComponent,
                            content: {
                              ...selectedComponent.content,
                              alt: {
                                ...selectedComponent.content.alt,
                                en: e.target.value
                              }
                            }
                          };
                          setSelectedComponent(updatedComponent);
                          updateComponentInPage(updatedComponent);
                        }}
                        className="w-full border border-slate-200 rounded-lg p-2"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2">
              {editingPage.components.map((component, index) => (
                <div
                  key={component.id}
                  className="border border-slate-200 rounded-lg p-4 bg-slate-50"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <GripVertical className="text-slate-400" size={16} />
                      {getComponentIcon(component.type)}
                      <span className="font-medium text-slate-700">
                        {component.type} - {component.display}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => moveComponent(index, 'up')}
                        disabled={index === 0}
                        className="p-1 text-slate-400 hover:text-slate-600 disabled:opacity-50"
                      >
                        <ArrowUp size={14} />
                      </button>
                      <button
                        onClick={() => moveComponent(index, 'down')}
                        disabled={index === editingPage.components.length - 1}
                        className="p-1 text-slate-400 hover:text-slate-600 disabled:opacity-50"
                      >
                        <ArrowDown size={14} />
                      </button>
                      <button
                        onClick={() => setSelectedComponent(component)}
                        className="p-1 text-blue-600 hover:text-blue-700"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button
                        onClick={() => deleteComponent(component.id)}
                        className="p-1 text-red-600 hover:text-red-700"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  
                  {/* Component Preview */}
                  <div className="text-sm text-slate-600">
                    {component.type === 'text' && component.content.text?.[lang]}
                    {component.type === 'button' && component.content.text?.[lang]}
                    {component.type === 'image' && component.content.alt?.[lang]}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">
          {lang === 'ar' ? 'مدير الصفحات' : 'Page Manager'}
        </h2>
        <button
          onClick={createNewPage}
          className="bg-tivro-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-500 flex items-center gap-2"
        >
          <Plus size={16} />
          {lang === 'ar' ? 'صفحة جديدة' : 'New Page'}
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('pages')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'pages'
                ? 'border-tivro-primary text-tivro-primary'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {lang === 'ar' ? 'الصفحات' : 'Pages'}
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'templates'
                ? 'border-tivro-primary text-tivro-primary'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {lang === 'ar' ? 'القوالب' : 'Templates'}
          </button>
          <button
            onClick={() => setActiveTab('navigation')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'navigation'
                ? 'border-tivro-primary text-tivro-primary'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {lang === 'ar' ? 'القائمة' : 'Navigation'}
          </button>
        </nav>
      </div>

      {/* Pages Tab */}
      {activeTab === 'pages' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left p-4 font-medium text-slate-700">
                    {lang === 'ar' ? 'الاسم' : 'Name'}
                  </th>
                  <th className="text-left p-4 font-medium text-slate-700">
                    {lang === 'ar' ? 'المسار' : 'URL'}
                  </th>
                  <th className="text-left p-4 font-medium text-slate-700">
                    {lang === 'ar' ? 'الحالة' : 'Status'}
                  </th>
                  <th className="text-left p-4 font-medium text-slate-700">
                    {lang === 'ar' ? 'المكونات' : 'Components'}
                  </th>
                  <th className="text-left p-4 font-medium text-slate-700">
                    {lang === 'ar' ? 'إجراءات' : 'Actions'}
                  </th>
                </tr>
              </thead>
              <tbody>
                {pages.map((page) => (
                  <tr key={page.id} className="border-b border-slate-100">
                    <td className="p-4">
                      <div>
                        <div className="font-medium text-slate-900">{page.name}</div>
                        <div className="text-sm text-slate-500">{page.title[lang]}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <code className="bg-slate-100 px-2 py-1 rounded text-sm">
                        /{page.slug}
                      </code>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          page.isVisible 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {page.isVisible 
                            ? (lang === 'ar' ? 'مرئي' : 'Visible')
                            : (lang === 'ar' ? 'مخفي' : 'Hidden')
                          }
                        </span>
                        {page.showInNavigation && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {lang === 'ar' ? 'في القائمة' : 'In Nav'}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-slate-500">
                        {page.components.length} {lang === 'ar' ? 'مكون' : 'components'}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => togglePageVisibility(page.id)}
                          className="p-1 text-slate-400 hover:text-slate-600"
                        >
                          {page.isVisible ? <Eye size={16} /> : <EyeOff size={16} />}
                        </button>
                        <button
                          onClick={() => setEditingPage(page)}
                          className="p-1 text-blue-600 hover:text-blue-700"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => deletePage(page.id)}
                          className="p-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Templates Tab */}
      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <div key={template.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="mb-4">
                <h3 className="font-bold text-slate-900 mb-2">
                  {template.displayName[lang]}
                </h3>
                <p className="text-sm text-slate-600 mb-2">
                  {template.description[lang]}
                </p>
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-800">
                  {template.category}
                </span>
              </div>
              <div className="text-sm text-slate-500 mb-4">
                {template.defaultComponents.length} {lang === 'ar' ? 'مكون' : 'components'}
              </div>
              <button
                onClick={() => {
                  if (editingPage) {
                    addComponentToPage(template.id);
                  }
                }}
                disabled={!editingPage}
                className="w-full bg-tivro-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-500 disabled:opacity-50"
              >
                {lang === 'ar' ? 'استخدم القالب' : 'Use Template'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Navigation Tab */}
      {activeTab === 'navigation' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-900 mb-4">
            {lang === 'ar' ? 'إدارة القائمة' : 'Navigation Management'}
          </h3>
          <p className="text-slate-600">
            {lang === 'ar' 
              ? 'سيتم إضافة إدارة القائمة في التحديث القادم' 
              : 'Navigation management will be added in the next update'
            }
          </p>
        </div>
      )}
    </div>
  );
};
