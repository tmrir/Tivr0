import { useState, useEffect } from 'react';

interface SettingsData {
  contact_email: string;
  contact_phone: string;
  social_links: any[];
  address: any;
  logo_url?: string;
  icon_url?: string;
  footer_logo_url?: string;
  favicon_url?: string;
  [key: string]: any;
}

export function useSettings() {
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function fetchSettings() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/settings/get');
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('Invalid response from server');
      }
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Failed to fetch settings');
      setSettings(json.data);
    } catch (err: any) {
      console.error('❌ [Hook] Fetch Settings Error:', err);
      setError(err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings(payload: Partial<SettingsData>) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/settings/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('Invalid response from server');
      }
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Failed to save settings');
      setSettings(json.data);
    } catch (err: any) {
      console.error('❌ [Hook] Save Settings Error:', err);
      setError(err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  async function restoreSettings() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/settings/restore', { method: 'POST' });
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('Invalid response from server');
      }
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Failed to restore settings');
      setSettings(json.data);
    } catch (err: any) {
      console.error('❌ [Hook] Restore Settings Error:', err);
      setError(err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchSettings();
  }, []);

  return { settings, loading, error, fetchSettings, saveSettings, restoreSettings };
}